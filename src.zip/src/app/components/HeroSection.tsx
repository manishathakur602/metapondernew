"use client";
import React from "react";
import Image from "next/image";
import Imagethree from "../../../public/Images/Imagethree.jpg";

function HeroSection() {
  return (
    <section className="relative pb-10 overflow-hidden bg-gradient-to-b from-white via-[#dcdcdf] to-[#525676] min-h-[720px]">
      {/* Decorative Gradient Blobs */}
      <div className="absolute top-0 left-0 w-[420px] h-[420px] bg-gradient-to-br from-indigo-200/40 via-blue-200/40 to-[#b0b5e4]/60 rounded-full blur-3xl opacity-70 -translate-x-1/2 -translate-y-1/3 animate-blob z-0"></div>
      <div className="absolute bottom-0 right-0 w-[360px] h-[360px] bg-gradient-to-br from-purple-300/40 via-[#b0b5e4]/60 to-pink-300/40 rounded-full blur-3xl opacity-70 translate-x-1/4 translate-y-1/4 animate-blob animation-delay-2000 z-0"></div>

      {/* Main Content - Text Left, Image Right */}
      <div className="relative mx-auto max-w-7xl px-6 pt-16 flex flex-col md:flex-row items-center justify-between gap-12">
        {/* Left Side - Text */}
        <div className="flex-1 text-left">
          <h1 className="text-xl md:text-4xl  mr-7 font-bold text-gray-900 leading-snug drop-shadow-md">
            Transforming Education with Smart Digital Solutions  
        
          </h1>
          <p className="mt-6 text-base sm:text-lg md:text-xl text-black max-w-xl leading-relaxed">
            Metaponder pioneers next-generation SaaS solutions tailored specifically for Universities, Autonomous Colleges, and Schools. With over two decades of expertise in the education sector, we empower institutions to streamline operations, enhance the student experience, and drive measurable academic success. Our innovative platforms are designed to transform educational environments, fostering growth, efficiency, and improved outcomes for both educators and students.
          </p>
        </div>

        {/* Right Side - Image */}
        <div className="flex-1 flex justify-center relative z-10">
          <div className="shadow-2xl rounded-xl overflow-hidden bg-white/80 backdrop-blur-lg border border-white/30 max-w-md">
            <Image
              src={Imagethree}
              alt="ERP Modules"
              className="object-cover w-full h-auto"
              priority
            />
          </div>
        </div>
      </div>

      {/* Floating User Avatars */}
      <img
        src="https://cdn.prod.website-files.com/66a76e2a019784d7d9a1624d/66b46ae18dda7c04e57d3583_4-%20User%20Image.webp"
        alt="User 1"
        className="absolute left-6 top-32 w-12 h-12 rounded-full object-cover shadow-lg animate-float z-20"
      />
      <img
        src="https://cdn.prod.website-files.com/66a76e2a019784d7d9a1624d/66b46ae1ec7834b604f37f4c_2-%20User%20Image.webp"
        alt="User 2"
        className="absolute right-6 top-36 w-12 h-12 rounded-full object-cover shadow-lg animate-float animation-delay-1000 z-20"
      />

      {/* Animations & Glass Effect */}
      <style jsx>{`
        @keyframes float {
          0% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-15px);
          }
          100% {
            transform: translateY(0px);
          }
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }
        .animate-blob {
          animation: blob 8s infinite;
        }
        .animation-delay-1000 {
          animation-delay: 1s;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
      `}</style>
    </section>
  );
}

export default HeroSection;
