import Image from "next/image";
import HeroSection from "./components/HeroSection";
import SectionC from "./components/SectionC";
import SectionD from "./components/SectionD";
import SectionE from "./components/SectionE";
import Aboutone from "./components/Aboutone";
import Abouttwo from "./components/Abouttwo";
import Ums from "./components/Ums";

export default function Home() {
  return (
    <>
    <div className=" bg-gradient-to-b from-white via-[#dcdcdf] to-[#525676]">
    <HeroSection />
      <SectionC />
    <Abouttwo />
    <SectionD />
    <SectionE />
    <Ums />

    </div>
    </>
  );
}
